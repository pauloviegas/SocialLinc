-- phpMyAdmin SQL Dump
-- version 2.11.8.1deb5+lenny9
-- http://www.phpmyadmin.net
--
-- Máquina: 200.239.64.109
-- Data de Criação: 16-Mar-2015 às 13:04
-- Versão do servidor: 5.5.41
-- versão do PHP: 5.2.6-1+lenny16

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de Dados: `guarana_linc`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `aiml`
--

CREATE TABLE IF NOT EXISTS `aiml` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bot_id` int(11) NOT NULL DEFAULT '1',
  `aiml` text NOT NULL,
  `pattern` varchar(255) NOT NULL,
  `thatpattern` varchar(255) NOT NULL,
  `template` text NOT NULL,
  `topic` varchar(255) NOT NULL,
  `filename` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `topic` (`topic`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1499 ;

--
-- Extraindo dados da tabela `aiml`
--

INSERT INTO `aiml` (`id`, `bot_id`, `aiml`, `pattern`, `thatpattern`, `template`, `topic`, `filename`) VALUES
(1491, 1, '<category><pattern>QUAIS DADOS NECESSÁRIOS PARA A DEFINIÇÃO DOS SITES</pattern><template><random><li>É necessário nome, formação, função no projeto, vínculo empregatício. E da equipe de TI: Local de trabalho;Carga horária;Telefone;E-mail.</li></random></template></category>', 'QUAIS DADOS NECESSÁRIOS PARA A DEFINIÇÃO DOS SITES', '', '<random><li>É necessário nome, formação, função no projeto, vínculo empregatício. E da equipe de TI: Local de trabalho;Carga horária;Telefone;E-mail.</li></random>', '', 'sites.aiml'),
(1490, 1, '<category><pattern>O MINICOM INTERFERE NA INSTALAÇÃO DE UM PAG EM LOCAL QUE NÃO SEJA DE PROPRIEDADE DO MUNICÍPIO</pattern><template><srai>HÁ ALGUM IMPEDIMENTO DA PARTE DO MINICOM QUANTO A INSTALAÇÃO DE UM PAG EM LOCAL QUE NÃO SEJA DE PROPRIEDADE DO MUNICÍPIO</srai></template></category>', 'O MINICOM INTERFERE NA INSTALAÇÃO DE UM PAG EM LOCAL QUE NÃO SEJA DE PROPRIEDADE DO MUNICÍPIO', '', '<srai>HÁ ALGUM IMPEDIMENTO DA PARTE DO MINICOM QUANTO A INSTALAÇÃO DE UM PAG EM LOCAL QUE NÃO SEJA DE PROPRIEDADE DO MUNICÍPIO</srai>', '', 'sites.aiml'),
(1489, 1, '<category><pattern>O MINICOM IMPEDE A INSTALAÇÃO DE PAG EM LOCAL QUE NÃO SEJA DE PROPRIEDADE DO MUNICÍPIO</pattern><template><srai>HÁ ALGUM IMPEDIMENTO DA PARTE DO MINICOM QUANTO A INSTALAÇÃO DE UM PAG EM LOCAL QUE NÃO SEJA DE PROPRIEDADE DO MUNICÍPIO</srai></template></category>', 'O MINICOM IMPEDE A INSTALAÇÃO DE PAG EM LOCAL QUE NÃO SEJA DE PROPRIEDADE DO MUNICÍPIO', '', '<srai>HÁ ALGUM IMPEDIMENTO DA PARTE DO MINICOM QUANTO A INSTALAÇÃO DE UM PAG EM LOCAL QUE NÃO SEJA DE PROPRIEDADE DO MUNICÍPIO</srai>', '', 'sites.aiml'),
(1488, 1, '<category><pattern>HÁ INTERFERÊNCIA DA PARTE DO MINICOM QUANTO A INSTALAÇÃO DE PAG''S</pattern><template><srai>HÁ ALGUM IMPEDIMENTO DA PARTE DO MINICOM QUANTO A INSTALAÇÃO DE UM PAG EM LOCAL QUE NÃO SEJA DE PROPRIEDADE DO MUNICÍPIO</srai></template></category>', 'HÁ INTERFERÊNCIA DA PARTE DO MINICOM QUANTO A INSTALAÇÃO DE PAG S', '', '<srai>HÁ ALGUM IMPEDIMENTO DA PARTE DO MINICOM QUANTO A INSTALAÇÃO DE UM PAG EM LOCAL QUE NÃO SEJA DE PROPRIEDADE DO MUNICÍPIO</srai>', '', 'sites.aiml'),
(1487, 1, '<category><pattern>HÁ ALGUM IMPEDIMENTO DA PARTE DO MINICOM QUANTO A INSTALAÇÃO DE UM PAG EM LOCAL QUE NÃO SEJA DE PROPRIEDADE DO MUNICÍPIO</pattern><template><random><li>O MC não recomenda a instalação de um PAG em um prédio que não seja da prefeitura porque caso haja mudança de endereço, a prefeitura terá de arcar com o custo de remoção dos equipamentos, nova instalação no novo prédio e adaptação do anel de fibra óptica.</li></random></template></category>', 'HÁ ALGUM IMPEDIMENTO DA PARTE DO MINICOM QUANTO A INSTALAÇÃO DE UM PAG EM LOCAL QUE NÃO SEJA DE PROPRIEDADE DO MUNICÍPIO', '', '<random><li>O MC não recomenda a instalação de um PAG em um prédio que não seja da prefeitura porque caso haja mudança de endereço, a prefeitura terá de arcar com o custo de remoção dos equipamentos, nova instalação no novo prédio e adaptação do anel de fibra óptica.</li></random>', '', 'sites.aiml'),
(1486, 1, '<category><pattern>QUE FORMAÇÃO AS PESSOAS DA EQUIPE DE TI IRÃO POSSUIR</pattern><template><srai>A TAREFA FOI COLOCADA EM 50% CONCLUÍDA, O QUE FALTA PARA FICAR 100%</srai></template></category>', 'QUE FORMAÇÃO AS PESSOAS DA EQUIPE DE TI IRÃO POSSUIR', '', '<srai>A TAREFA FOI COLOCADA EM 50% CONCLUÍDA, O QUE FALTA PARA FICAR 100%</srai>', '', 'equipeTI.aiml'),
(1485, 1, '<category><pattern>QUE CARGO AS PESSOAS DA EQUIPE DE TI IRÃO TER</pattern><template><srai>A TAREFA FOI COLOCADA EM 50% CONCLUÍDA, O QUE FALTA PARA FICAR 100%</srai></template></category>', 'QUE CARGO AS PESSOAS DA EQUIPE DE TI IRÃO TER', '', '<srai>A TAREFA FOI COLOCADA EM 50% CONCLUÍDA, O QUE FALTA PARA FICAR 100%</srai>', '', 'equipeTI.aiml'),
(1482, 1, '<category><pattern>QUAL FORMAÇÃO E QUAL CARGO QUE IRÃO ASSUMIR</pattern><template><srai>A TAREFA FOI COLOCADA EM 50% CONCLUÍDA, O QUE FALTA PARA FICAR 100%</srai></template></category>', 'QUAL FORMAÇÃO E QUAL CARGO QUE IRÃO ASSUMIR', '', '<srai>A TAREFA FOI COLOCADA EM 50% CONCLUÍDA, O QUE FALTA PARA FICAR 100%</srai>', '', 'equipeTI.aiml'),
(1483, 1, '<category><pattern>QUE FORMAÇÃO A EQUIPE DE TI IRÁ TER</pattern><template><srai>A TAREFA FOI COLOCADA EM 50% CONCLUÍDA, O QUE FALTA PARA FICAR 100%</srai></template></category>', 'QUE FORMAÇÃO A EQUIPE DE TI IRÁ TER', '', '<srai>A TAREFA FOI COLOCADA EM 50% CONCLUÍDA, O QUE FALTA PARA FICAR 100%</srai>', '', 'equipeTI.aiml'),
(1484, 1, '<category><pattern>QUE CARGO A EQUIPE DE TI IRÁ ASSUMIR</pattern><template><srai>A TAREFA FOI COLOCADA EM 50% CONCLUÍDA, O QUE FALTA PARA FICAR 100%</srai></template></category>', 'QUE CARGO A EQUIPE DE TI IRÁ ASSUMIR', '', '<srai>A TAREFA FOI COLOCADA EM 50% CONCLUÍDA, O QUE FALTA PARA FICAR 100%</srai>', '', 'equipeTI.aiml'),
(1481, 1, '<category><pattern>ELES FARÃO OS CURSOS DE FORMAÇÃO DO PROJETO. DE PREFERÊNCIA QUE SEJAM PESSOAS QUE POSSUEM ALGUMA LIGAÇÃO COM A ÁREA.</pattern><template><srai>A TAREFA FOI COLOCADA EM 50% CONCLUÍDA, O QUE FALTA PARA FICAR 100%</srai></template></category>', 'ELES FARÃO OS CURSOS DE FORMAÇÃO DO PROJETO. DE PREFERÊNCIA QUE SEJAM PESSOAS QUE POSSUEM ALGUMA LIGAÇÃO COM A ÁREA.', '', '<srai>A TAREFA FOI COLOCADA EM 50% CONCLUÍDA, O QUE FALTA PARA FICAR 100%</srai>', '', 'equipeTI.aiml'),
(1480, 1, '<category><pattern>O QUE FALTA PARA COMPLETAR A TAREFA</pattern><template><srai>A TAREFA FOI COLOCADA EM 50% CONCLUÍDA, O QUE FALTA PARA FICAR 100%</srai></template></category>', 'O QUE FALTA PARA COMPLETAR A TAREFA', '', '<srai>A TAREFA FOI COLOCADA EM 50% CONCLUÍDA, O QUE FALTA PARA FICAR 100%</srai>', '', 'equipeTI.aiml'),
(1478, 1, '<category><pattern>QUANTO FALTA PARA A TAREFA FICAR EM 100%</pattern><template><srai>A TAREFA FOI COLOCADA EM 50% CONCLUÍDA, O QUE FALTA PARA FICAR 100%</srai></template></category>', 'QUANTO FALTA PARA A TAREFA FICAR EM 100%', '', '<srai>A TAREFA FOI COLOCADA EM 50% CONCLUÍDA, O QUE FALTA PARA FICAR 100%</srai>', '', 'equipeTI.aiml'),
(1479, 1, '<category><pattern>QUANTO FALTA PARA A TAREFA ESTAR CONCLUÍDA</pattern><template><srai>A TAREFA FOI COLOCADA EM 50% CONCLUÍDA, O QUE FALTA PARA FICAR 100%</srai></template></category>', 'QUANTO FALTA PARA A TAREFA ESTAR CONCLUÍDA', '', '<srai>A TAREFA FOI COLOCADA EM 50% CONCLUÍDA, O QUE FALTA PARA FICAR 100%</srai>', '', 'equipeTI.aiml'),
(1477, 1, '<category><pattern>O QUE FALTA PARA A TAREFA SER CONSIDERADA CONCLUÍDA</pattern><template><srai>A TAREFA FOI COLOCADA EM 50% CONCLUÍDA, O QUE FALTA PARA FICAR 100%</srai></template></category>', 'O QUE FALTA PARA A TAREFA SER CONSIDERADA CONCLUÍDA', '', '<srai>A TAREFA FOI COLOCADA EM 50% CONCLUÍDA, O QUE FALTA PARA FICAR 100%</srai>', '', 'equipeTI.aiml'),
(1475, 1, '<category><pattern>É POSSÍVEL TROCAR A EQUIPE DE TI</pattern><template><srai>PODE EFETUAR A ALTERAÇÃO DA EQUIPE DE TI</srai></template></category>', 'É POSSÍVEL TROCAR A EQUIPE DE TI', '', '<srai>PODE EFETUAR A ALTERAÇÃO DA EQUIPE DE TI</srai>', '', 'equipeTI.aiml'),
(1476, 1, '<category><pattern>A TAREFA FOI COLOCADA EM 50% CONCLUÍDA, O QUE FALTA PARA FICAR 100%</pattern><template><random><li>Algumas informções são necessárias para que a tarefa seja concluída como: nome, formação, local de trabalho, carga horária, email.</li></random></template></category>', 'A TAREFA FOI COLOCADA EM 50% CONCLUÍDA, O QUE FALTA PARA FICAR 100%', '', '<random><li>Algumas informções são necessárias para que a tarefa seja concluída como: nome, formação, local de trabalho, carga horária, email.</li></random>', '', 'equipeTI.aiml'),
(1474, 1, '<category><pattern>PODE TROCAR MEMBROS DA EQUIPE DE TI</pattern><template><srai>PODE EFETUAR A ALTERAÇÃO DA EQUIPE DE TI</srai></template></category>', 'PODE TROCAR MEMBROS DA EQUIPE DE TI', '', '<srai>PODE EFETUAR A ALTERAÇÃO DA EQUIPE DE TI</srai>', '', 'equipeTI.aiml'),
(1473, 1, '<category><pattern>TROCAR EQUIPE DE TI</pattern><template><srai>PODE EFETUAR A ALTERAÇÃO DA EQUIPE DE TI</srai></template></category>', 'TROCAR EQUIPE DE TI', '', '<srai>PODE EFETUAR A ALTERAÇÃO DA EQUIPE DE TI</srai>', '', 'equipeTI.aiml'),
(1472, 1, '<category><pattern>PODE MUDAR EQUIPE DE TI</pattern><template><srai>PODE EFETUAR A ALTERAÇÃO DA EQUIPE DE TI</srai></template></category>', 'PODE MUDAR EQUIPE DE TI', '', '<srai>PODE EFETUAR A ALTERAÇÃO DA EQUIPE DE TI</srai>', '', 'equipeTI.aiml'),
(1471, 1, '<category><pattern>A EQUIPE DE TI PODE SER ALTERADA</pattern><template><srai>PODE EFETUAR A ALTERAÇÃO DA EQUIPE DE TI</srai></template></category>', 'A EQUIPE DE TI PODE SER ALTERADA', '', '<srai>PODE EFETUAR A ALTERAÇÃO DA EQUIPE DE TI</srai>', '', 'equipeTI.aiml'),
(1470, 1, '<category><pattern>A EQUIPE PODE MODIFICAR</pattern><template><srai>PODE EFETUAR A ALTERAÇÃO DA EQUIPE DE TI</srai></template></category>', 'A EQUIPE PODE MODIFICAR', '', '<srai>PODE EFETUAR A ALTERAÇÃO DA EQUIPE DE TI</srai>', '', 'equipeTI.aiml'),
(1468, 1, '<category><pattern>A EQUIPE DE TI PODE SOFRER ALTERAÇÕES</pattern><template><srai>PODE EFETUAR A ALTERAÇÃO DA EQUIPE DE TI</srai></template></category>', 'A EQUIPE DE TI PODE SOFRER ALTERAÇÕES', '', '<srai>PODE EFETUAR A ALTERAÇÃO DA EQUIPE DE TI</srai>', '', 'equipeTI.aiml'),
(1469, 1, '<category><pattern>A EQUIPE DE TI PODE ALTERAR</pattern><template><srai>PODE EFETUAR A ALTERAÇÃO DA EQUIPE DE TI</srai></template></category>', 'A EQUIPE DE TI PODE ALTERAR', '', '<srai>PODE EFETUAR A ALTERAÇÃO DA EQUIPE DE TI</srai>', '', 'equipeTI.aiml'),
(1467, 1, '<category><pattern>A EQUIPE DE TI PODE MUDAR</pattern><template><srai>PODE EFETUAR A ALTERAÇÃO DA EQUIPE DE TI</srai></template></category>', 'A EQUIPE DE TI PODE MUDAR', '', '<srai>PODE EFETUAR A ALTERAÇÃO DA EQUIPE DE TI</srai>', '', 'equipeTI.aiml'),
(1466, 1, '<category><pattern>PODE EFETUAR A ALTERAÇÃO DA EQUIPE DE TI</pattern><template><random><li>A alteração da equipe de TI pode ser realizada, mandar em anexo para efetuar a atualização.</li></random></template></category>', 'PODE EFETUAR A ALTERAÇÃO DA EQUIPE DE TI', '', '<random><li>A alteração da equipe de TI pode ser realizada, mandar em anexo para efetuar a atualização.</li></random>', '', 'equipeTI.aiml'),
(1464, 1, '<category><pattern>QUANTAS PESSOAS DE TI</pattern><template><srai>QUAL A QUANTIDADE DE MEMBROS PARA COMPOR A EQUIPE DE T.I</srai></template></category>', 'QUANTAS PESSOAS DE TI', '', '<srai>QUAL A QUANTIDADE DE MEMBROS PARA COMPOR A EQUIPE DE T.I</srai>', '', 'equipeTI.aiml'),
(1465, 1, '<category><pattern>PESSOAS NA EQUIPE DE TI</pattern><template><srai>QUAL A QUANTIDADE DE MEMBROS PARA COMPOR A EQUIPE DE T.I</srai></template></category>', 'PESSOAS NA EQUIPE DE TI', '', '<srai>QUAL A QUANTIDADE DE MEMBROS PARA COMPOR A EQUIPE DE T.I</srai>', '', 'equipeTI.aiml'),
(1463, 1, '<category><pattern>A QUANTIDADE DE PESSOAS DA EQUIPE DE TI É QUANTOS</pattern><template><srai>QUAL A QUANTIDADE DE MEMBROS PARA COMPOR A EQUIPE DE T.I</srai></template></category>', 'A QUANTIDADE DE PESSOAS DA EQUIPE DE TI É QUANTOS', '', '<srai>QUAL A QUANTIDADE DE MEMBROS PARA COMPOR A EQUIPE DE T.I</srai>', '', 'equipeTI.aiml'),
(1462, 1, '<category><pattern>QUANTAS PESSOAS A EQUIPE DE TI DEVE TER</pattern><template><srai>QUAL A QUANTIDADE DE MEMBROS PARA COMPOR A EQUIPE DE T.I</srai></template></category>', 'QUANTAS PESSOAS A EQUIPE DE TI DEVE TER', '', '<srai>QUAL A QUANTIDADE DE MEMBROS PARA COMPOR A EQUIPE DE T.I</srai>', '', 'equipeTI.aiml'),
(1461, 1, '<category><pattern>QUAL A QUANTIDADE DE MEMBROS PARA COMPOR A EQUIPE DE T.I</pattern><template><random><li>A equipe de TI deve ser composta de até 5 pessoas.</li></random></template></category>', 'QUAL A QUANTIDADE DE MEMBROS PARA COMPOR A EQUIPE DE T.I', '', '<random><li>A equipe de TI deve ser composta de até 5 pessoas.</li></random>', '', 'equipeTI.aiml'),
(1460, 1, '<category><pattern>O QUE REALIZAR APÓS A MUDANÇA DA EQUIPE</pattern><template><srai>HOUVE MUDANÇA NA EQUIPE DE TI</srai></template></category>', 'O QUE REALIZAR APÓS A MUDANÇA DA EQUIPE', '', '<srai>HOUVE MUDANÇA NA EQUIPE DE TI</srai>', '', 'equipeTI.aiml'),
(1459, 1, '<category><pattern>O QUE FAZER COM A MUDANÇA DE EQUIPE DE TI</pattern><template><srai>HOUVE MUDANÇA NA EQUIPE DE TI</srai></template></category>', 'O QUE FAZER COM A MUDANÇA DE EQUIPE DE TI', '', '<srai>HOUVE MUDANÇA NA EQUIPE DE TI</srai>', '', 'equipeTI.aiml'),
(1458, 1, '<category><pattern>HOUVE MUDANÇA NA EQUIPE DE TI</pattern><template><random><li>Mandar em anexo, nova formação da equipe de TI para realizar a atualização.</li></random></template></category>', 'HOUVE MUDANÇA NA EQUIPE DE TI', '', '<random><li>Mandar em anexo, nova formação da equipe de TI para realizar a atualização.</li></random>', '', 'equipeTI.aiml'),
(1457, 1, '<category><pattern>DADOS PARA INFORMA PARA CRIAÇÃO DA EQUIPE DE TI</pattern><template><srai>QUAIS DADOS NECESSÁRIOS PARA INFORMAÇÃO DA EQUIPE DE TI</srai></template></category>', 'DADOS PARA INFORMA PARA CRIAÇÃO DA EQUIPE DE TI', '', '<srai>QUAIS DADOS NECESSÁRIOS PARA INFORMAÇÃO DA EQUIPE DE TI</srai>', '', 'equipeTI.aiml'),
(1456, 1, '<category><pattern>INFORMAÇÕES NECESSÁRIAS PARA EQUIPE DE TI</pattern><template><srai>QUAIS DADOS NECESSÁRIOS PARA INFORMAÇÃO DA EQUIPE DE TI</srai></template></category>', 'INFORMAÇÕES NECESSÁRIAS PARA EQUIPE DE TI', '', '<srai>QUAIS DADOS NECESSÁRIOS PARA INFORMAÇÃO DA EQUIPE DE TI</srai>', '', 'equipeTI.aiml'),
(1455, 1, '<category><pattern>O QUE PRECISA PARA A FORMAÇÃO DA EQUIPE DE TI</pattern><template><srai>QUAIS DADOS NECESSÁRIOS PARA INFORMAÇÃO DA EQUIPE DE TI</srai></template></category>', 'O QUE PRECISA PARA A FORMAÇÃO DA EQUIPE DE TI', '', '<srai>QUAIS DADOS NECESSÁRIOS PARA INFORMAÇÃO DA EQUIPE DE TI</srai>', '', 'equipeTI.aiml'),
(1454, 1, '<category><pattern>QUAIS DADOS NECESSÁRIOS PARA INFORMAÇÃO DA EQUIPE DE TI</pattern><template><random><li>Os dados necessários são: Nome, formação, local de trabalho, carga horária, telefone, email.</li></random></template></category>', 'QUAIS DADOS NECESSÁRIOS PARA INFORMAÇÃO DA EQUIPE DE TI', '', '<random><li>Os dados necessários são: Nome, formação, local de trabalho, carga horária, telefone, email.</li></random>', '', 'equipeTI.aiml'),
(1453, 1, '<category><pattern>QUERO O CONTRATO FIRMADO ENTRE O MINICOM E A EMPRESA</pattern><template><srai>SOLICITO O CONTRATO FIRMADO ENTRE O MINICOM E A EMPRESA INTEGRADORA (PETCOM)</srai></template></category>', 'QUERO O CONTRATO FIRMADO ENTRE O MINICOM E A EMPRESA', '', '<srai>SOLICITO O CONTRATO FIRMADO ENTRE O MINICOM E A EMPRESA INTEGRADORA (PETCOM)</srai>', '', 'contato_cidade.aiml'),
(1452, 1, '<category><pattern>NECESSITO DO CONTRATO FIRMADO ENTRE O MINICOM E A EMPRESA</pattern><template><srai>SOLICITO O CONTRATO FIRMADO ENTRE O MINICOM E A EMPRESA INTEGRADORA (PETCOM)</srai></template></category>', 'NECESSITO DO CONTRATO FIRMADO ENTRE O MINICOM E A EMPRESA', '', '<srai>SOLICITO O CONTRATO FIRMADO ENTRE O MINICOM E A EMPRESA INTEGRADORA (PETCOM)</srai>', '', 'contato_cidade.aiml'),
(1451, 1, '<category><pattern>SOLICITO O CONTRATO FIRMADO ENTRE O MINICOM E A EMPRESA INTEGRADORA (PETCOM)</pattern><template><random><li>Conforme solicitado, encaminho anexo, contrato firmado entre o MiniCom e a impresa integradora (PETCOM), sobre o Projeto Cidades Digitais - Piloto.(ANEXAR O DOCUMENTO Contrato n° 036-2012.pdf , contato com a cidade pag 4).</li></random></template></category>', 'SOLICITO O CONTRATO FIRMADO ENTRE O MINICOM E A EMPRESA INTEGRADORA (PETCOM)', '', '<random><li>Conforme solicitado, encaminho anexo, contrato firmado entre o MiniCom e a impresa integradora (PETCOM), sobre o Projeto Cidades Digitais - Piloto.(ANEXAR O DOCUMENTO Contrato n° 036-2012.pdf , contato com a cidade pag 4).</li></random>', '', 'contato_cidade.aiml'),
(1450, 1, '<category><pattern>QUEM PODE REPRESENTAR O PREFEITO PARA TRATAR DE ASSUNTOS REFERENTES AO PROJETO</pattern><template><srai>PARA TRATAR DE ASSUNTOS REFERENTES AO PROJETO, PODE SER UM REPRESENTANTE DO PREFEITO(A)</srai></template></category>', 'QUEM PODE REPRESENTAR O PREFEITO PARA TRATAR DE ASSUNTOS REFERENTES AO PROJETO', '', '<srai>PARA TRATAR DE ASSUNTOS REFERENTES AO PROJETO, PODE SER UM REPRESENTANTE DO PREFEITO(A)</srai>', '', 'contato_cidade.aiml'),
(1449, 1, '<category><pattern>SOMENTE O PREFEITO PODE TRATAR DE ASSUNTOS DO PROJETO</pattern><template><srai>PARA TRATAR DE ASSUNTOS REFERENTES AO PROJETO, PODE SER UM REPRESENTANTE DO PREFEITO(A)</srai></template></category>', 'SOMENTE O PREFEITO PODE TRATAR DE ASSUNTOS DO PROJETO', '', '<srai>PARA TRATAR DE ASSUNTOS REFERENTES AO PROJETO, PODE SER UM REPRESENTANTE DO PREFEITO(A)</srai>', '', 'contato_cidade.aiml'),
(1448, 1, '<category><pattern>UM REPRESENTANTE DO PREFEITO PODE TRATAR DE ASSUNTOS REFERENTES AO PROJETO</pattern><template><srai>PARA TRATAR DE ASSUNTOS REFERENTES AO PROJETO, PODE SER UM REPRESENTANTE DO PREFEITO(A)</srai></template></category>', 'UM REPRESENTANTE DO PREFEITO PODE TRATAR DE ASSUNTOS REFERENTES AO PROJETO', '', '<srai>PARA TRATAR DE ASSUNTOS REFERENTES AO PROJETO, PODE SER UM REPRESENTANTE DO PREFEITO(A)</srai>', '', 'contato_cidade.aiml'),
(1447, 1, '<category><pattern>QUAL O RESPONSÁVEL PARA TRATAR DE ASSUNTOS DO PROJETO</pattern><template><srai>PARA TRATAR DE ASSUNTOS REFERENTES AO PROJETO, PODE SER UM REPRESENTANTE DO PREFEITO(A)</srai></template></category>', 'QUAL O RESPONSÁVEL PARA TRATAR DE ASSUNTOS DO PROJETO', '', '<srai>PARA TRATAR DE ASSUNTOS REFERENTES AO PROJETO, PODE SER UM REPRESENTANTE DO PREFEITO(A)</srai>', '', 'contato_cidade.aiml'),
(1446, 1, '<category><pattern>QUEM DEVE TRATAR DE ASSUNTOS REFERENTES AO PROJETO</pattern><template><srai>PARA TRATAR DE ASSUNTOS REFERENTES AO PROJETO, PODE SER UM REPRESENTANTE DO PREFEITO(A)</srai></template></category>', 'QUEM DEVE TRATAR DE ASSUNTOS REFERENTES AO PROJETO', '', '<srai>PARA TRATAR DE ASSUNTOS REFERENTES AO PROJETO, PODE SER UM REPRESENTANTE DO PREFEITO(A)</srai>', '', 'contato_cidade.aiml'),
(1445, 1, '<category><pattern>PARA TRATAR DE ASSUNTOS REFERENTES AO PROJETO, PODE SER UM REPRESENTANTE DO PREFEITO(A)</pattern><template><random><li>Caso o Prefeito(a) não possa comparecer, é necessário que o representante seja alguém que esteja acompanhando o Projeto Cidade Digital no Municipio.</li></random></template></category>', 'PARA TRATAR DE ASSUNTOS REFERENTES AO PROJETO, PODE SER UM REPRESENTANTE DO PREFEITO(A)', '', '<random><li>Caso o Prefeito(a) não possa comparecer, é necessário que o representante seja alguém que esteja acompanhando o Projeto Cidade Digital no Municipio.</li></random>', '', 'contato_cidade.aiml'),
(1444, 1, '<category><pattern>QUAL  A SITUAÇÃO DO PROJETO EM MINHA REGIÃO</pattern><template><srai>COMO ESTÁ O PROCESSO DO PROJETO EM MEU ESTADO</srai></template></category>', 'QUAL  A SITUAÇÃO DO PROJETO EM MINHA REGIÃO', '', '<srai>COMO ESTÁ O PROCESSO DO PROJETO EM MEU ESTADO</srai>', '', 'contato_cidade.aiml'),
(1443, 1, '<category><pattern>COMO ESTÁ O PROJETO EM MEU ESTADO</pattern><template><srai>COMO ESTÁ O PROCESSO DO PROJETO EM MEU ESTADO</srai></template></category>', 'COMO ESTÁ O PROJETO EM MEU ESTADO', '', '<srai>COMO ESTÁ O PROCESSO DO PROJETO EM MEU ESTADO</srai>', '', 'contato_cidade.aiml'),
(1442, 1, '<category><pattern>COMO ESTÁ A SITUAÇÃO DO PROCESSO DO PROJETO EM MINHA LOCALIDADE</pattern><template><srai>COMO ESTÁ O PROCESSO DO PROJETO EM MEU ESTADO</srai></template></category>', 'COMO ESTÁ A SITUAÇÃO DO PROCESSO DO PROJETO EM MINHA LOCALIDADE', '', '<srai>COMO ESTÁ O PROCESSO DO PROJETO EM MEU ESTADO</srai>', '', 'contato_cidade.aiml'),
(1441, 1, '<category><pattern>QUAL O ESTADO DO PROCESSO DO PROJETO EM MINHA CIDADE</pattern><template><srai>COMO ESTÁ O PROCESSO DO PROJETO EM MEU ESTADO</srai></template></category>', 'QUAL O ESTADO DO PROCESSO DO PROJETO EM MINHA CIDADE', '', '<srai>COMO ESTÁ O PROCESSO DO PROJETO EM MEU ESTADO</srai>', '', 'contato_cidade.aiml'),
(1440, 1, '<category><pattern>QUAL O ESTADO ATUAL DO PROJETO EM MINHA REGIÃO</pattern><template><srai>COMO ESTÁ O PROCESSO DO PROJETO EM MEU ESTADO</srai></template></category>', 'QUAL O ESTADO ATUAL DO PROJETO EM MINHA REGIÃO', '', '<srai>COMO ESTÁ O PROCESSO DO PROJETO EM MEU ESTADO</srai>', '', 'contato_cidade.aiml'),
(1439, 1, '<category><pattern>COM ENCONTRA-SE O PROJETO EM MEU ESTADO</pattern><template><srai>COMO ESTÁ O PROCESSO DO PROJETO EM MEU ESTADO</srai></template></category>', 'COM ENCONTRA-SE O PROJETO EM MEU ESTADO', '', '<srai>COMO ESTÁ O PROCESSO DO PROJETO EM MEU ESTADO</srai>', '', 'contato_cidade.aiml'),
(1438, 1, '<category><pattern>COMO ESTÁ O ANDAMENTO DO PROJETO EM MEU MUNICÍPIO</pattern><template><srai>COMO ESTÁ O PROCESSO DO PROJETO EM MEU ESTADO</srai></template></category>', 'COMO ESTÁ O ANDAMENTO DO PROJETO EM MEU MUNICÍPIO', '', '<srai>COMO ESTÁ O PROCESSO DO PROJETO EM MEU ESTADO</srai>', '', 'contato_cidade.aiml'),
(1437, 1, '<category><pattern>QUAL O ANDAMENTO DO PROCESSO DO PROJETO EM MEU ESTDADO</pattern><template><srai>COMO ESTÁ O PROCESSO DO PROJETO EM MEU ESTADO</srai></template></category>', 'QUAL O ANDAMENTO DO PROCESSO DO PROJETO EM MEU ESTDADO', '', '<srai>COMO ESTÁ O PROCESSO DO PROJETO EM MEU ESTADO</srai>', '', 'contato_cidade.aiml'),
(1436, 1, '<category><pattern>COMO ESTÁ O PROCESSO DO PROJETO EM MEU ESTADO</pattern><template><random><li>#andamento</li></random></template></category>', 'COMO ESTÁ O PROCESSO DO PROJETO EM MEU ESTADO', '', '<random><li>#andamento</li></random>', '', 'contato_cidade.aiml'),
(1435, 1, '<category><pattern>QUAL LOCAL ENCONTRA-SE O CRONOGRAMA</pattern><template><srai>QUAL O CRONOGRAMA DE EXECUÇÃO DO PROJETO</srai></template></category>', 'QUAL LOCAL ENCONTRA-SE O CRONOGRAMA', '', '<srai>QUAL O CRONOGRAMA DE EXECUÇÃO DO PROJETO</srai>', '', 'contato_cidade.aiml'),
(1434, 1, '<category><pattern>O CRONOGRAMA ENCONTRA-SE NO FÓRUM</pattern><template><srai>QUAL O CRONOGRAMA DE EXECUÇÃO DO PROJETO</srai></template></category>', 'O CRONOGRAMA ENCONTRA-SE NO FÓRUM', '', '<srai>QUAL O CRONOGRAMA DE EXECUÇÃO DO PROJETO</srai>', '', 'contato_cidade.aiml'),
(1433, 1, '<category><pattern>ESTOU COM DIFICULDADES PARA ENCONTRAR O CRONOGRAMA DO PROJETO, PODE ME AJUDAR</pattern><template><srai>QUAL O CRONOGRAMA DE EXECUÇÃO DO PROJETO</srai></template></category>', 'ESTOU COM DIFICULDADES PARA ENCONTRAR O CRONOGRAMA DO PROJETO, PODE ME AJUDAR', '', '<srai>QUAL O CRONOGRAMA DE EXECUÇÃO DO PROJETO</srai>', '', 'contato_cidade.aiml'),
(1432, 1, '<category><pattern>ONDE ENCONTRO O CRONOGRAMA</pattern><template><srai>QUAL O CRONOGRAMA DE EXECUÇÃO DO PROJETO</srai></template></category>', 'ONDE ENCONTRO O CRONOGRAMA', '', '<srai>QUAL O CRONOGRAMA DE EXECUÇÃO DO PROJETO</srai>', '', 'contato_cidade.aiml'),
(1431, 1, '<category><pattern>ENCONTRA-SE ONDE O CRONOGRAMA DE EXECUÇÃO DO PROJETO</pattern><template><srai>QUAL O CRONOGRAMA DE EXECUÇÃO DO PROJETO</srai></template></category>', 'ENCONTRA-SE ONDE O CRONOGRAMA DE EXECUÇÃO DO PROJETO', '', '<srai>QUAL O CRONOGRAMA DE EXECUÇÃO DO PROJETO</srai>', '', 'contato_cidade.aiml'),
(1429, 1, '<category><pattern>ONDE ESTÁ O CRONOGRAMA</pattern><template><srai>QUAL O CRONOGRAMA DE EXECUÇÃO DO PROJETO</srai></template></category>', 'ONDE ESTÁ O CRONOGRAMA', '', '<srai>QUAL O CRONOGRAMA DE EXECUÇÃO DO PROJETO</srai>', '', 'contato_cidade.aiml'),
(1430, 1, '<category><pattern>QUAL A LOCALIZAÇÃO DO CRONOGRAMA DE EXECUÇÃO DO PROJETO</pattern><template><srai>QUAL O CRONOGRAMA DE EXECUÇÃO DO PROJETO</srai></template></category>', 'QUAL A LOCALIZAÇÃO DO CRONOGRAMA DE EXECUÇÃO DO PROJETO', '', '<srai>QUAL O CRONOGRAMA DE EXECUÇÃO DO PROJETO</srai>', '', 'contato_cidade.aiml'),
(1428, 1, '<category><pattern>ONDE ESTÁ LOCALIZADO O CRONOGRAMA DE EXECUÇÃO DO PROJETO</pattern><template><srai>QUAL O CRONOGRAMA DE EXECUÇÃO DO PROJETO</srai></template></category>', 'ONDE ESTÁ LOCALIZADO O CRONOGRAMA DE EXECUÇÃO DO PROJETO', '', '<srai>QUAL O CRONOGRAMA DE EXECUÇÃO DO PROJETO</srai>', '', 'contato_cidade.aiml'),
(1427, 1, '<category><pattern>QUAL O CRONOGRAMA DE EXECUÇÃO DO PROJETO</pattern><template><random><li>O cronograma é encontrado no plano de trabalho, assinado pela prefeitura.</li></random></template></category>', 'QUAL O CRONOGRAMA DE EXECUÇÃO DO PROJETO', '', '<random><li>O cronograma é encontrado no plano de trabalho, assinado pela prefeitura.</li></random>', '', 'contato_cidade.aiml'),
(1426, 1, '<category><pattern>DEVE HAVER QUAIS INFORMAÇÕES DO COORDENADOR</pattern><template><srai>DADOS NECESSÁRIOS DO COORDENADOR DE ACOMPANHAMENTO DO PROJETO</srai></template></category>', 'DEVE HAVER QUAIS INFORMAÇÕES DO COORDENADOR', '', '<srai>DADOS NECESSÁRIOS DO COORDENADOR DE ACOMPANHAMENTO DO PROJETO</srai>', '', 'contato_cidade.aiml'),
(1425, 1, '<category><pattern>QUAIS DOCUMENTOS NECESSÁRIOS DO COORDENADOR</pattern><template><srai>DADOS NECESSÁRIOS DO COORDENADOR DE ACOMPANHAMENTO DO PROJETO</srai></template></category>', 'QUAIS DOCUMENTOS NECESSÁRIOS DO COORDENADOR', '', '<srai>DADOS NECESSÁRIOS DO COORDENADOR DE ACOMPANHAMENTO DO PROJETO</srai>', '', 'contato_cidade.aiml'),
(1424, 1, '<category><pattern>QUAL INFORMAÇÕES DO COORDENADOR DEVEM SER APRESENTADAS</pattern><template><srai>DADOS NECESSÁRIOS DO COORDENADOR DE ACOMPANHAMENTO DO PROJETO</srai></template></category>', 'QUAL INFORMAÇÕES DO COORDENADOR DEVEM SER APRESENTADAS', '', '<srai>DADOS NECESSÁRIOS DO COORDENADOR DE ACOMPANHAMENTO DO PROJETO</srai>', '', 'contato_cidade.aiml'),
(1423, 1, '<category><pattern>É NECESSÁRIO O EMAIL DO COORDENADOR</pattern><template><srai>DADOS NECESSÁRIOS DO COORDENADOR DE ACOMPANHAMENTO DO PROJETO</srai></template></category>', 'É NECESSÁRIO O EMAIL DO COORDENADOR', '', '<srai>DADOS NECESSÁRIOS DO COORDENADOR DE ACOMPANHAMENTO DO PROJETO</srai>', '', 'contato_cidade.aiml'),
(1422, 1, '<category><pattern>É NECESSÁRIO O TELEFONE DO COORDENADOR</pattern><template><srai>DADOS NECESSÁRIOS DO COORDENADOR DE ACOMPANHAMENTO DO PROJETO</srai></template></category>', 'É NECESSÁRIO O TELEFONE DO COORDENADOR', '', '<srai>DADOS NECESSÁRIOS DO COORDENADOR DE ACOMPANHAMENTO DO PROJETO</srai>', '', 'contato_cidade.aiml'),
(1421, 1, '<category><pattern>É NECESSÁRIO A DESCRIÇÃO DA FORMAÇÃO DO COORDENADOR</pattern><template><srai>DADOS NECESSÁRIOS DO COORDENADOR DE ACOMPANHAMENTO DO PROJETO</srai></template></category>', 'É NECESSÁRIO A DESCRIÇÃO DA FORMAÇÃO DO COORDENADOR', '', '<srai>DADOS NECESSÁRIOS DO COORDENADOR DE ACOMPANHAMENTO DO PROJETO</srai>', '', 'contato_cidade.aiml'),
(1420, 1, '<category><pattern>É PRECISO EMAIL DO COORDENADOR</pattern><template><srai>DADOS NECESSÁRIOS DO COORDENADOR DE ACOMPANHAMENTO DO PROJETO</srai></template></category>', 'É PRECISO EMAIL DO COORDENADOR', '', '<srai>DADOS NECESSÁRIOS DO COORDENADOR DE ACOMPANHAMENTO DO PROJETO</srai>', '', 'contato_cidade.aiml'),
(1419, 1, '<category><pattern>É PRECISO O TELEFONE DO COORDENADOR</pattern><template><srai>DADOS NECESSÁRIOS DO COORDENADOR DE ACOMPANHAMENTO DO PROJETO</srai></template></category>', 'É PRECISO O TELEFONE DO COORDENADOR', '', '<srai>DADOS NECESSÁRIOS DO COORDENADOR DE ACOMPANHAMENTO DO PROJETO</srai>', '', 'contato_cidade.aiml'),
(1418, 1, '<category><pattern>É PRECISO A DESCRIÇÃO DA FORMAÇÃO DO COORDENADOR</pattern><template><srai>DADOS NECESSÁRIOS DO COORDENADOR DE ACOMPANHAMENTO DO PROJETO</srai></template></category>', 'É PRECISO A DESCRIÇÃO DA FORMAÇÃO DO COORDENADOR', '', '<srai>DADOS NECESSÁRIOS DO COORDENADOR DE ACOMPANHAMENTO DO PROJETO</srai>', '', 'contato_cidade.aiml'),
(1417, 1, '<category><pattern>O QUE PRECISA PARA REALIZAR O CADASTRO DO COORDENADOR</pattern><template><srai>DADOS NECESSÁRIOS DO COORDENADOR DE ACOMPANHAMENTO DO PROJETO</srai></template></category>', 'O QUE PRECISA PARA REALIZAR O CADASTRO DO COORDENADOR', '', '<srai>DADOS NECESSÁRIOS DO COORDENADOR DE ACOMPANHAMENTO DO PROJETO</srai>', '', 'contato_cidade.aiml'),
(1416, 1, '<category><pattern>QUAL INFORMAÇÕES NECESSÁRIAS DO COORDENADOR</pattern><template><srai>DADOS NECESSÁRIOS DO COORDENADOR DE ACOMPANHAMENTO DO PROJETO</srai></template></category>', 'QUAL INFORMAÇÕES NECESSÁRIAS DO COORDENADOR', '', '<srai>DADOS NECESSÁRIOS DO COORDENADOR DE ACOMPANHAMENTO DO PROJETO</srai>', '', 'contato_cidade.aiml'),
(1415, 1, '<category><pattern>É NECESSÁRIO CPF DO COORDENADOR</pattern><template><srai>DADOS NECESSÁRIOS DO COORDENADOR DE ACOMPANHAMENTO DO PROJETO</srai></template></category>', 'É NECESSÁRIO CPF DO COORDENADOR', '', '<srai>DADOS NECESSÁRIOS DO COORDENADOR DE ACOMPANHAMENTO DO PROJETO</srai>', '', 'contato_cidade.aiml'),
(1414, 1, '<category><pattern>DADOS NECESSÁRIOS DO COORDENADOR DE ACOMPANHAMENTO DO PROJETO</pattern><template><random><li>São necessários: nome, formação, telefone fixo, celular e email.</li></random></template></category>', 'DADOS NECESSÁRIOS DO COORDENADOR DE ACOMPANHAMENTO DO PROJETO', '', '<random><li>São necessários: nome, formação, telefone fixo, celular e email.</li></random>', '', 'contato_cidade.aiml'),
(1410, 1, '<category><pattern>UHM</pattern><template><srai>OI</srai></template></category>', 'UHM', '', '<srai>OI</srai>', '', 'educacao.aiml'),
(1411, 1, '<category><pattern>AHM</pattern><template><srai>OI</srai></template></category>', 'AHM', '', '<srai>OI</srai>', '', 'educacao.aiml'),
(1412, 1, '<category><pattern>AH</pattern><template><srai>OI</srai></template></category>', 'AH', '', '<srai>OI</srai>', '', 'educacao.aiml'),
(1413, 1, '<category><pattern>OH</pattern><template><srai>OI</srai></template></category>', 'OH', '', '<srai>OI</srai>', '', 'educacao.aiml'),
(1407, 1, '<category><pattern>ALOW</pattern><template><srai>OI</srai></template></category>', 'ALOW', '', '<srai>OI</srai>', '', 'educacao.aiml'),
(1408, 1, '<category><pattern>ALOU</pattern><template><srai>OI</srai></template></category>', 'ALOU', '', '<srai>OI</srai>', '', 'educacao.aiml'),
(1409, 1, '<category><pattern>OE</pattern><template><srai>OI</srai></template></category>', 'OE', '', '<srai>OI</srai>', '', 'educacao.aiml'),
(1405, 1, '<category><pattern>OIE</pattern><template><srai>OI</srai></template></category>', 'OIE', '', '<srai>OI</srai>', '', 'educacao.aiml'),
(1406, 1, '<category><pattern>ALO</pattern><template><srai>OI</srai></template></category>', 'ALO', '', '<srai>OI</srai>', '', 'educacao.aiml'),
(1402, 1, '<category><pattern>OLÁ</pattern><template><srai>OI</srai></template></category>', 'OLÁ', '', '<srai>OI</srai>', '', 'educacao.aiml'),
(1403, 1, '<category><pattern>FALE</pattern><template><srai>OI</srai></template></category>', 'FALE', '', '<srai>OI</srai>', '', 'educacao.aiml'),
(1404, 1, '<category><pattern>SALVE</pattern><template><srai>OI</srai></template></category>', 'SALVE', '', '<srai>OI</srai>', '', 'educacao.aiml'),
(1400, 1, '<category><pattern>PROBLEMAS</pattern><template><srai>COMO VOCÊ ESTÁ</srai></template></category>', 'PROBLEMAS', '', '<srai>COMO VOCÊ ESTÁ</srai>', '', 'educacao.aiml'),
(1401, 1, '<category><pattern>OI</pattern><template><random><li>Oi. Me pergunte algo sobre o #SID , estou aqui pra esclarecer suas dúvidas</li></random></template></category>', 'OI', '', '<random><li>Oi. Me pergunte algo sobre o #SID , estou aqui pra esclarecer suas dúvidas</li></random>', '', 'educacao.aiml'),
(1398, 1, '<category><pattern>VOCÊ TÁ OK</pattern><template><srai>COMO VOCÊ ESTÁ</srai></template></category>', 'VOCÊ TÁ OK', '', '<srai>COMO VOCÊ ESTÁ</srai>', '', 'educacao.aiml'),
(1399, 1, '<category><pattern>ALGUM PROBLEMA</pattern><template><srai>COMO VOCÊ ESTÁ</srai></template></category>', 'ALGUM PROBLEMA', '', '<srai>COMO VOCÊ ESTÁ</srai>', '', 'educacao.aiml'),
(1394, 1, '<category><pattern>COMO VAI</pattern><template><srai>COMO VOCÊ ESTÁ</srai></template></category>', 'COMO VAI', '', '<srai>COMO VOCÊ ESTÁ</srai>', '', 'educacao.aiml'),
(1395, 1, '<category><pattern>TUDO CERTINHO</pattern><template><srai>COMO VOCÊ ESTÁ</srai></template></category>', 'TUDO CERTINHO', '', '<srai>COMO VOCÊ ESTÁ</srai>', '', 'educacao.aiml'),
(1396, 1, '<category><pattern>TUDO OK</pattern><template><srai>COMO VOCÊ ESTÁ</srai></template></category>', 'TUDO OK', '', '<srai>COMO VOCÊ ESTÁ</srai>', '', 'educacao.aiml'),
(1397, 1, '<category><pattern>VOCÊ TÁ BEM</pattern><template><srai>COMO VOCÊ ESTÁ</srai></template></category>', 'VOCÊ TÁ BEM', '', '<srai>COMO VOCÊ ESTÁ</srai>', '', 'educacao.aiml'),
(1392, 1, '<category><pattern>TUDO CERTO</pattern><template><srai>COMO VOCÊ ESTÁ</srai></template></category>', 'TUDO CERTO', '', '<srai>COMO VOCÊ ESTÁ</srai>', '', 'educacao.aiml'),
(1393, 1, '<category><pattern>E AÍ</pattern><template><srai>COMO VOCÊ ESTÁ</srai></template></category>', 'E AÍ', '', '<srai>COMO VOCÊ ESTÁ</srai>', '', 'educacao.aiml'),
(1390, 1, '<category><pattern>COMO VOCÊ ESTÁ</pattern><template><random><li>Estou bem, em que posso lhe ajudar hoje?</li></random></template></category>', 'COMO VOCÊ ESTÁ', '', '<random><li>Estou bem, em que posso lhe ajudar hoje?</li></random>', '', 'educacao.aiml'),
(1391, 1, '<category><pattern>TUDO BEM</pattern><template><srai>COMO VOCÊ ESTÁ</srai></template></category>', 'TUDO BEM', '', '<srai>COMO VOCÊ ESTÁ</srai>', '', 'educacao.aiml'),
(1492, 1, '<category><pattern>O QUE É PRECISO PARA DEFINIÇÃO DO SITE</pattern><template><srai>QUAIS DADOS NECESSÁRIOS PARA A DEFINIÇÃO DOS SITES</srai></template></category>', 'O QUE É PRECISO PARA DEFINIÇÃO DO SITE', '', '<srai>QUAIS DADOS NECESSÁRIOS PARA A DEFINIÇÃO DOS SITES</srai>', '', 'sites.aiml'),
(1493, 1, '<category><pattern>QUAIS DOCUMENTOS OU INFORMAÇÕES PARA DEFINIÇÃO DO SITE</pattern><template><srai>QUAIS DADOS NECESSÁRIOS PARA A DEFINIÇÃO DOS SITES</srai></template></category>', 'QUAIS DOCUMENTOS OU INFORMAÇÕES PARA DEFINIÇÃO DO SITE', '', '<srai>QUAIS DADOS NECESSÁRIOS PARA A DEFINIÇÃO DOS SITES</srai>', '', 'sites.aiml'),
(1494, 1, '<category><pattern>PARA DEFINIÇÃO DO SITE, O QUE É NECESSÁRIO</pattern><template><srai>QUAIS DADOS NECESSÁRIOS PARA A DEFINIÇÃO DOS SITES</srai></template></category>', 'PARA DEFINIÇÃO DO SITE, O QUE É NECESSÁRIO', '', '<srai>QUAIS DADOS NECESSÁRIOS PARA A DEFINIÇÃO DOS SITES</srai>', '', 'sites.aiml'),
(1495, 1, '<category><pattern>POR ONDE DEVE SER FEITO O ENVIO DO OFÍCIO</pattern><template><random><li>Anexar no sistema, no tópico de Definição dos Sites, (http://projetos.sid.mc.gov.br/issues/2013)</li></random></template></category>', 'POR ONDE DEVE SER FEITO O ENVIO DO OFÍCIO', '', '<random><li>Anexar no sistema, no tópico de Definição dos Sites, (http://projetos.sid.mc.gov.br/issues/2013)</li></random>', '', 'sites.aiml'),
(1496, 1, '<category><pattern>PELO SISTEMA O OFÍCIO DEVE SER ENVIADO</pattern><template><srai>POR ONDE DEVE SER FEITO O ENVIO DO OFÍCIO</srai></template></category>', 'PELO SISTEMA O OFÍCIO DEVE SER ENVIADO', '', '<srai>POR ONDE DEVE SER FEITO O ENVIO DO OFÍCIO</srai>', '', 'sites.aiml'),
(1497, 1, '<category><pattern>PARA ONDE O OFÍCIO DEVE SER ENVIADO</pattern><template><srai>POR ONDE DEVE SER FEITO O ENVIO DO OFÍCIO</srai></template></category>', 'PARA ONDE O OFÍCIO DEVE SER ENVIADO', '', '<srai>POR ONDE DEVE SER FEITO O ENVIO DO OFÍCIO</srai>', '', 'sites.aiml'),
(1498, 1, '<category><pattern>O OFÍCIO DEVE SER ENVIADO PELO SISTEMA</pattern><template><srai>POR ONDE DEVE SER FEITO O ENVIO DO OFÍCIO</srai></template></category>', 'O OFÍCIO DEVE SER ENVIADO PELO SISTEMA', '', '<srai>POR ONDE DEVE SER FEITO O ENVIO DO OFÍCIO</srai>', '', 'sites.aiml');

-- --------------------------------------------------------

--
-- Estrutura da tabela `aiml_userdefined`
--

CREATE TABLE IF NOT EXISTS `aiml_userdefined` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aiml` text NOT NULL,
  `pattern` text NOT NULL,
  `thatpattern` text NOT NULL,
  `template` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `bot_id` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `aiml_userdefined`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `botpersonality`
--

CREATE TABLE IF NOT EXISTS `botpersonality` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bot_id` tinyint(4) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `botname` (`bot_id`,`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=61 ;

--
-- Extraindo dados da tabela `botpersonality`
--

INSERT INTO `botpersonality` (`id`, `bot_id`, `name`, `value`) VALUES
(1, 1, 'name', 'Sid O. McBot'),
(2, 1, 'gender', 'Male'),
(3, 1, 'botmaster', 'MC'),
(4, 1, 'master', ''),
(5, 1, 'age', '1'),
(6, 1, 'website', ''),
(7, 1, 'email', ''),
(8, 1, 'birthday', '6/2'),
(9, 1, 'birthplace', 'Laboratório Kids, UFPA'),
(10, 1, 'size', 'BIG'),
(11, 1, 'version', '0.1.2a'),
(12, 1, 'build', '0.1'),
(13, 1, 'language', 'Português Brasileiro'),
(14, 1, 'feelings', ''),
(15, 1, 'etype', ''),
(16, 1, 'emotions', ''),
(17, 1, 'ethics', ''),
(18, 1, 'orientation', ''),
(19, 1, 'baseballteam', ''),
(20, 1, 'footballteam', ''),
(21, 1, 'hockeyteam', ''),
(22, 1, 'favoritesport', ''),
(23, 1, 'vocabulary', ''),
(24, 1, 'celebrities', ''),
(25, 1, 'celebrity', ''),
(26, 1, 'favoriteactor', ''),
(27, 1, 'favoriteactress', ''),
(28, 1, 'favoriteartist', ''),
(29, 1, 'favoritemusician', ''),
(30, 1, 'favoritesong', ''),
(31, 1, 'favoriteauthor', ''),
(32, 1, 'friend', ''),
(33, 1, 'nationality', ''),
(34, 1, 'religion', ''),
(35, 1, 'president', ''),
(36, 1, 'party', ''),
(37, 1, 'kingdom', ''),
(38, 1, 'phylum', ''),
(39, 1, 'class', ''),
(40, 1, 'order', ''),
(41, 1, 'family', ''),
(42, 1, 'genus', ''),
(43, 1, 'species', ''),
(44, 1, 'boyfriend', ''),
(45, 1, 'favoritebook', ''),
(46, 1, 'favoriteband', ''),
(47, 1, 'favoritecolor', ''),
(48, 1, 'favoritefood', ''),
(49, 1, 'favoritemovie', ''),
(50, 1, 'forfun', ''),
(51, 1, 'friends', ''),
(52, 1, 'girlfriend', ''),
(53, 1, 'kindmusic', ''),
(54, 1, 'location', ''),
(55, 1, 'looklike', ''),
(56, 1, 'question', ''),
(57, 1, 'sign', ''),
(58, 1, 'talkabout', ''),
(59, 1, 'wear', ''),
(60, 1, 'loves', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `bots`
--

CREATE TABLE IF NOT EXISTS `bots` (
  `bot_id` int(11) NOT NULL AUTO_INCREMENT,
  `bot_name` varchar(255) NOT NULL,
  `bot_desc` varchar(255) NOT NULL,
  `bot_active` int(11) NOT NULL DEFAULT '1',
  `bot_parent_id` int(11) NOT NULL DEFAULT '0',
  `format` varchar(10) NOT NULL DEFAULT 'html',
  `save_state` enum('session','database') NOT NULL DEFAULT 'session',
  `conversation_lines` int(11) NOT NULL DEFAULT '7',
  `remember_up_to` int(11) NOT NULL DEFAULT '10',
  `debugemail` text NOT NULL,
  `debugshow` int(11) NOT NULL DEFAULT '1',
  `debugmode` int(11) NOT NULL DEFAULT '1',
  `error_response` text NOT NULL,
  `default_aiml_pattern` varchar(255) NOT NULL DEFAULT 'RANDOM PICKUP LINE',
  `unknown_user` varchar(255) NOT NULL DEFAULT 'Seeker',
  PRIMARY KEY (`bot_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `bots`
--

INSERT INTO `bots` (`bot_id`, `bot_name`, `bot_desc`, `bot_active`, `bot_parent_id`, `format`, `save_state`, `conversation_lines`, `remember_up_to`, `debugemail`, `debugshow`, `debugmode`, `error_response`, `default_aiml_pattern`, `unknown_user`) VALUES
(1, 'Sid McBot', 'Robô esclarecedor de dúvidas sobre o projeto SID do MC', 1, 1, 'html', 'database', 1, 10, 'romulogabriel@outlook.com', 4, 1, 'Ainda não tenho resposta para esta pergunta.', 'RANDOM PICKUP LINE', 'usuário');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cidade`
--

CREATE TABLE IF NOT EXISTS `cidade` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `estado_id` int(11) NOT NULL,
  `nome` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `nome_UNIQUE` (`nome`),
  KEY `estado_idx` (`estado_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=99 ;

--
-- Extraindo dados da tabela `cidade`
--

INSERT INTO `cidade` (`id`, `estado_id`, `nome`) VALUES
(1, 1, 'Coari'),
(2, 1, 'Manacapuru'),
(3, 1, 'Manaquiri'),
(4, 2, 'Serra do Navio'),
(5, 3, 'Guanambi'),
(6, 3, 'Itaberaba'),
(7, 3, 'Itabuna'),
(8, 3, 'Juazeiro'),
(9, 3, 'Lauro de Freitas'),
(10, 3, 'Nilo Peçanha'),
(11, 3, 'Piraí do Norte'),
(12, 3, 'Uruçucá'),
(13, 3, 'Vitória da Conquista'),
(14, 4, 'Araripe'),
(15, 4, 'Barreira'),
(16, 4, 'Brejo Santo'),
(17, 4, 'Jaguaruana'),
(18, 4, 'Maracanaú'),
(19, 4, 'Milhã'),
(20, 4, 'Quixeramobim'),
(21, 4, 'São Gonçalo do Amarante'),
(22, 4, 'Varjota'),
(23, 4, 'Viçosa do Ceará'),
(24, 5, 'Estrutural'),
(25, 6, 'Cariacica'),
(26, 7, 'São José do Ribamar'),
(27, 8, 'Nepomuceno'),
(28, 8, 'Pimenta'),
(29, 8, 'Rio Acima'),
(30, 9, 'Conceição do Araguaia'),
(31, 9, 'Curuçá'),
(32, 9, 'Goianésia do Pará'),
(33, 9, 'Itaituba'),
(34, 9, 'Marituba'),
(35, 9, 'Paragominas'),
(36, 9, 'Trairão'),
(37, 9, 'Tucuruí'),
(38, 9, 'Uruará'),
(39, 10, 'Cabaceiras'),
(40, 10, 'Cachoeira dos Índios'),
(41, 10, 'Esperança'),
(42, 10, 'Itaporanga'),
(43, 10, 'Lagoa Seca'),
(44, 10, 'Nova Floresta'),
(45, 10, 'Pocinhos'),
(46, 10, 'Queimadas'),
(47, 10, 'São João do Rio do Peixe'),
(48, 11, 'Bodocó'),
(49, 11, 'Casinhas'),
(50, 11, 'Correntes'),
(51, 12, 'Inhuma'),
(52, 12, 'Regeneração'),
(53, 12, 'São José do Divino'),
(54, 13, 'Assis Chateaubriand'),
(55, 13, 'Bandeirantes'),
(56, 13, 'Ibiporã'),
(57, 13, 'Palmas'),
(58, 13, 'Quatro Barras'),
(59, 13, 'Santa Cecília do Pavão'),
(60, 13, 'São Miguel do Iguaçu'),
(61, 13, 'Toledo'),
(62, 14, 'Engenheiro Paulo de Frontin'),
(63, 14, 'Maricá'),
(64, 14, 'São José do Vale do Rio Preto'),
(65, 15, 'São João do Sabugi'),
(66, 16, 'Candelária'),
(67, 16, 'Jari'),
(68, 16, 'Não-me-toque'),
(69, 16, 'Nova Bassano'),
(70, 16, 'Santo Ângelo'),
(71, 16, 'São Miguel das Missões'),
(72, 17, 'Joaçaba'),
(73, 18, 'Casa Branca'),
(74, 18, 'Descalvado'),
(75, 18, 'Guararapes'),
(76, 18, 'Lourdes'),
(77, 18, 'Penápolis'),
(78, 18, 'Presidente Epitácio'),
(79, 18, 'Santa Gertrudes'),
(80, 18, 'Socorro'),
(81, 1, 'Estado de AM'),
(82, 2, 'Estado de AP'),
(83, 3, 'Estado de BA'),
(84, 4, 'Estado de CE'),
(85, 5, 'Estado de DF'),
(86, 6, 'Estado de ES'),
(87, 7, 'Estado de MA'),
(88, 8, 'Estado de MG'),
(89, 9, 'Estado de PA'),
(90, 10, 'Estado de PB'),
(91, 11, 'Estado de PE'),
(92, 12, 'Estado de PI'),
(93, 13, 'Estado de PR'),
(94, 14, 'Estado de RJ'),
(95, 15, 'Estado de RN'),
(96, 16, 'Estado de RS'),
(97, 17, 'Estado de SC'),
(98, 18, 'Estado de SP');

-- --------------------------------------------------------

--
-- Estrutura da tabela `client_properties`
--

CREATE TABLE IF NOT EXISTS `client_properties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `bot_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=52 ;

--
-- Extraindo dados da tabela `client_properties`
--

INSERT INTO `client_properties` (`id`, `user_id`, `bot_id`, `name`, `value`) VALUES
(1, 1, 1, 'name', 'Seeker'),
(2, 2, 1, 'name', 'Seeker'),
(3, 3, 1, 'name', 'Seeker'),
(4, 4, 1, 'name', 'Seeker'),
(5, 5, 1, 'name', 'Seeker'),
(6, 6, 1, 'name', 'Seeker'),
(7, 7, 1, 'name', 'Seeker'),
(8, 8, 1, 'name', 'Seeker'),
(9, 9, 1, 'name', 'Seeker'),
(10, 10, 1, 'name', 'Seeker'),
(11, 11, 1, 'name', 'Seeker'),
(12, 12, 1, 'name', 'Seeker'),
(13, 13, 1, 'name', 'Seeker'),
(14, 14, 1, 'name', 'Seeker'),
(15, 15, 1, 'name', 'Seeker'),
(16, 16, 1, 'name', 'Seeker'),
(17, 17, 1, 'name', 'Seeker'),
(18, 18, 1, 'name', 'Seeker'),
(19, 19, 1, 'name', 'Seeker'),
(20, 20, 1, 'name', 'Seeker'),
(21, 21, 1, 'name', 'Seeker'),
(22, 22, 1, 'name', 'Seeker'),
(23, 23, 1, 'name', 'Seeker'),
(24, 24, 1, 'name', 'Seeker'),
(25, 25, 1, 'name', 'Seeker'),
(26, 26, 1, 'name', 'Seeker'),
(27, 27, 1, 'name', 'Seeker'),
(28, 28, 1, 'name', 'Seeker'),
(29, 29, 1, 'name', 'Seeker'),
(30, 30, 1, 'name', 'usuário'),
(31, 31, 1, 'name', 'usuário'),
(32, 32, 1, 'name', 'usuário'),
(33, 33, 1, 'name', 'usuário'),
(34, 34, 1, 'name', 'usuário'),
(35, 35, 1, 'name', 'usuário'),
(36, 36, 1, 'name', 'usuário'),
(37, 37, 1, 'name', 'usuário'),
(38, 38, 1, 'name', 'usuário'),
(39, 39, 1, 'name', 'usuário'),
(40, 40, 1, 'name', 'usuário'),
(41, 41, 1, 'name', 'usuário'),
(42, 42, 1, 'name', 'usuário'),
(43, 43, 1, 'name', 'usuário'),
(44, 44, 1, 'name', 'usuário'),
(45, 45, 1, 'name', 'usuário'),
(46, 46, 1, 'name', 'usuário'),
(47, 47, 1, 'name', 'usuário'),
(48, 48, 1, 'name', 'usuário'),
(49, 49, 1, 'name', 'usuário'),
(50, 50, 1, 'name', 'usuário'),
(51, 51, 1, 'name', 'usuário');

-- --------------------------------------------------------

--
-- Estrutura da tabela `conversations`
--

CREATE TABLE IF NOT EXISTS `conversations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrada` varchar(45) DEFAULT NULL,
  `padrao` varchar(45) DEFAULT NULL,
  `convo_id` varchar(45) DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `conversations`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `conversation_log`
--

CREATE TABLE IF NOT EXISTS `conversation_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `input` text NOT NULL,
  `response` longtext NOT NULL,
  `user_id` int(11) NOT NULL,
  `convo_id` text NOT NULL,
  `bot_id` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=54 ;

--
-- Extraindo dados da tabela `conversation_log`
--

INSERT INTO `conversation_log` (`id`, `input`, `response`, `user_id`, `convo_id`, `bot_id`, `timestamp`) VALUES
(1, 'Onde estÃ¡ o cronograma?', '', 33, 'fa0ji86j18okoeltdcvjgbprq6', 1, '2014-08-31 13:34:19'),
(2, 'Onde estÃ¡ o cronograma?', '', 36, '6o8pjjbqtslciddtcl0cqhede6', 1, '2014-09-04 16:45:32'),
(3, 'Onde estÃ¡ o cronograma?', '', 37, '6rhk8snkpp8tdc4fdg1condj94', 1, '2014-09-04 16:46:22'),
(4, 'PARA ONDE O OFÃCIO DEVE SER ENVIADO?', '', 36, '6o8pjjbqtslciddtcl0cqhede6', 1, '2014-09-04 16:47:00'),
(5, 'Como vai?', 'Ainda n?o tenho resposta para esta pergunta.', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 10:36:06'),
(6, 'Como vai?', 'Ainda n?o tenho resposta para esta pergunta.', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 10:36:38'),
(7, 'OlÃ¡', 'Ainda n?o tenho resposta para esta pergunta.', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 11:14:30'),
(8, 'Como vai?', 'Ainda n?o tenho resposta para esta pergunta.', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 11:14:32'),
(9, 'Como vai?', 'Ainda n?o tenho resposta para esta pergunta.', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 11:27:55'),
(10, 'OlÃ¡', 'Ainda n?o tenho resposta para esta pergunta.', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 11:27:56'),
(11, 'OI', 'OI, como posso ajudar?', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 11:45:26'),
(12, 'OlÃ¡', 'Oi, em que posso lhe ajudar sobre o #SID?', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 11:45:29'),
(13, 'OlÃ¡', 'Oi, em que posso lhe ajudar sobre o #SID?', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 12:22:24'),
(14, 'Oi', 'Oi. Me pergunte algo sobre o #SID, estou aqui pra esclarecer suas d?vidas', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 12:52:16'),
(15, 'BNDES?', 'Ainda n?o tenho resposta para esta pergunta.', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 12:52:37'),
(16, 'OlÃ¡', 'Ainda n?o tenho resposta para esta pergunta.', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 14:08:16'),
(17, 'Como vai?', '', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 14:08:18'),
(18, 'OlÃ¡', 'Ainda n?o tenho resposta para esta pergunta.', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 14:31:00'),
(19, 'COmo vai?', 'Ainda n?o tenho resposta para esta pergunta.', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 14:31:03'),
(20, 'OlÃ¡', 'Ainda n?o tenho resposta para esta pergunta.', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 14:33:46'),
(21, 'Oi', 'Ainda n?o tenho resposta para esta pergunta.', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 14:33:49'),
(22, 'Quem?', 'Ainda n?o tenho resposta para esta pergunta.', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 14:33:51'),
(23, 'COmo?', 'Ainda n?o tenho resposta para esta pergunta.', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 14:33:54'),
(24, 'Onde estÃ¡ o cronograma do projeto?', 'Ainda n?o tenho resposta para esta pergunta.', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 14:34:01'),
(25, 'Como vai?', 'Ainda n?o tenho resposta para esta pergunta.', 47, 'rqthsvcv1a9mtdq9dargval0c3', 1, '2014-09-08 14:34:34'),
(26, 'Como?', 'Ainda n?o tenho resposta para esta pergunta.', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 14:35:07'),
(27, 'Como?', 'Ainda n?o tenho resposta para esta pergunta.', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 14:35:12'),
(28, 'OlÃ¡', 'Ainda n?o tenho resposta para esta pergunta.', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 14:35:45'),
(29, 'Como vai?', 'Ainda n?o tenho resposta para esta pergunta.', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 14:36:17'),
(30, 'COMO ESTÃ O PROJETO EM MEU ESTADO?', 'Ainda n?o tenho resposta para esta pergunta.', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 14:37:30'),
(31, 'COMO ESTÃ O PROJETO EM MEU ESTADO?', 'Ainda n?o tenho resposta para esta pergunta.', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 14:37:31'),
(32, 'COMO ESTÃ O PROJETO EM MEU ESTADO?', 'Ainda n?o tenho resposta para esta pergunta.', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 14:37:32'),
(33, 'COMO ESTÃ O PROJETO EM MEU ESTADO?', 'Ainda n?o tenho resposta para esta pergunta.', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 14:37:32'),
(34, 'COMO ESTÃ O PROJETO EM MEU ESTADO?', 'Ainda n?o tenho resposta para esta pergunta.', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 14:37:33'),
(35, 'COMO ESTÃ O PROJETO EM MEU ESTADO?', '', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 14:38:35'),
(36, 'Oi', 'Oi. Me pergunte algo sobre o #SID, estou aqui pra esclarecer suas d?vidas', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 14:39:49'),
(37, 'OlÃ¡', 'Ainda n?o tenho resposta para esta pergunta.', 42, 'po82pfbaq28ch0e4846g0k1bc2', 1, '2014-09-08 14:39:53'),
(38, 'Como vai?', '', 48, 'j95kd5pp22l9ekmqtdmfkcr126', 1, '2014-09-08 14:42:05'),
(39, 'OlÃ¡', 'Ainda n?o tenho resposta para esta pergunta.', 48, 'j95kd5pp22l9ekmqtdmfkcr126', 1, '2014-09-08 15:00:52'),
(40, 'alksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkv', 'Ainda n?o tenho resposta para esta pergunta.', 48, 'j95kd5pp22l9ekmqtdmfkcr126', 1, '2014-09-08 15:01:01'),
(41, 'alksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdk', 'Ainda n?o tenho resposta para esta pergunta.', 48, 'j95kd5pp22l9ekmqtdmfkcr126', 1, '2014-09-08 15:01:06'),
(42, 'alksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkalksnalsdknaldsknalsdkv', 'Ainda n?o tenho resposta para esta pergunta.', 48, 'j95kd5pp22l9ekmqtdmfkcr126', 1, '2014-09-08 15:01:08'),
(43, 'Como vai', '', 48, 'j95kd5pp22l9ekmqtdmfkcr126', 1, '2014-09-08 15:01:13'),
(44, 'BNDES', 'Ainda n?o tenho resposta para esta pergunta.', 48, 'j95kd5pp22l9ekmqtdmfkcr126', 1, '2014-09-08 15:01:15'),
(45, 'BNDES?', 'Ainda n?o tenho resposta para esta pergunta.', 48, 'j95kd5pp22l9ekmqtdmfkcr126', 1, '2014-09-08 15:01:18'),
(46, 'Como vai/', '', 48, 'j95kd5pp22l9ekmqtdmfkcr126', 1, '2014-09-08 15:47:42'),
(47, 'Ola?', '', 48, 'j95kd5pp22l9ekmqtdmfkcr126', 1, '2014-09-08 15:47:45'),
(48, 'TUdo bem?', '', 48, 'j95kd5pp22l9ekmqtdmfkcr126', 1, '2014-09-08 15:47:48'),
(49, 'POR ONDE DEVE SER FEITO O ENVIO DO OFÃCIO', '', 48, 'j95kd5pp22l9ekmqtdmfkcr126', 1, '2014-09-08 15:49:47'),
(50, 'COMO VOCÃŠ ESTÃ', '', 48, 'j95kd5pp22l9ekmqtdmfkcr126', 1, '2014-09-08 15:50:29'),
(51, 'Oi', 'Oi. Me pergunte algo sobre o #SID, estou aqui pra esclarecer suas d?vidas', 49, 'tlnr0n3ufk0ssinf9c5dt7ha06', 1, '2014-09-08 16:01:45'),
(52, 'Como vai?', '', 50, '8dptnseaifmo5cnk5v19qv8nk3', 1, '2014-09-08 16:01:57'),
(53, 'Como vai?', '', 51, '7hs7ffletc0t5p8v7kma0djsb5', 1, '2014-09-08 16:12:56');

-- --------------------------------------------------------

--
-- Estrutura da tabela `errors`
--

CREATE TABLE IF NOT EXISTS `errors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `time` datetime NOT NULL,
  `content` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `errors`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `estado`
--

CREATE TABLE IF NOT EXISTS `estado` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  `sigla` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `nome_UNIQUE` (`nome`),
  UNIQUE KEY `sigla_UNIQUE` (`sigla`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Extraindo dados da tabela `estado`
--

INSERT INTO `estado` (`id`, `nome`, `sigla`) VALUES
(1, 'amazonas', 'am'),
(2, 'amapá', 'ap'),
(3, 'bahia', 'ba'),
(4, 'ceará', 'ce'),
(5, 'distrito federal', 'df'),
(6, 'espírito santo', 'es'),
(7, 'maranhão', 'ma'),
(8, 'minas gerais', 'mg'),
(9, 'pará', 'pa'),
(10, 'paraíba', 'pb'),
(11, 'pernambuco', 'pe'),
(12, 'piauí', 'pi'),
(13, 'paraná', 'pr'),
(14, 'rio de janeiro', 'rj'),
(15, 'rio grande do norte', 'rn'),
(16, 'rio grande do sul', 'rs'),
(17, 'santa catarina', 'sc'),
(18, 'são paulo', 'sp');

-- --------------------------------------------------------

--
-- Estrutura da tabela `myprogramo`
--

CREATE TABLE IF NOT EXISTS `myprogramo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `last_ip` varchar(25) NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `myprogramo`
--

INSERT INTO `myprogramo` (`id`, `user_name`, `password`, `last_ip`, `last_login`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '200.239.72.1', '2014-09-08 15:47:05');

-- --------------------------------------------------------

--
-- Estrutura da tabela `replacements`
--

CREATE TABLE IF NOT EXISTS `replacements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(45) NOT NULL,
  `result` varchar(45) NOT NULL,
  `cidade_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `code_UNIQUE` (`code`),
  KEY `localidadeFK_idx` (`cidade_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `replacements`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `spellcheck`
--

CREATE TABLE IF NOT EXISTS `spellcheck` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `missspelling` varchar(100) NOT NULL,
  `correction` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `spellcheck`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `srai_lookup`
--

CREATE TABLE IF NOT EXISTS `srai_lookup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bot_id` int(11) NOT NULL,
  `pattern` text NOT NULL,
  `template_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pattern` (`bot_id`,`pattern`(64))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- Extraindo dados da tabela `srai_lookup`
--

INSERT INTO `srai_lookup` (`id`, `bot_id`, `pattern`, `template_id`) VALUES
(1, 1, 'COMO VOCÊ ESTÁ', 1390),
(2, 1, 'OI', 1401),
(3, 1, 'DADOS NECESSÁRIOS DO COORDENADOR DE ACOMPANHAMENTO DO PROJETO', 1414),
(4, 1, 'QUAL O CRONOGRAMA DE EXECUÇÃO DO PROJETO', 1427),
(5, 1, 'COMO ESTÁ O PROCESSO DO PROJETO EM MEU ESTADO', 1436),
(6, 1, 'PARA TRATAR DE ASSUNTOS REFERENTES AO PROJETO, PODE SER UM REPRESENTANTE DO PREFEITO(A)', 1445),
(7, 1, 'SOLICITO O CONTRATO FIRMADO ENTRE O MINICOM E A EMPRESA INTEGRADORA (PETCOM)', 1451),
(8, 1, 'QUAIS DADOS NECESSÁRIOS PARA INFORMAÇÃO DA EQUIPE DE TI', 1454),
(9, 1, 'HOUVE MUDANÇA NA EQUIPE DE TI', 1458),
(10, 1, 'QUAL A QUANTIDADE DE MEMBROS PARA COMPOR A EQUIPE DE T.I', 1461),
(11, 1, 'PODE EFETUAR A ALTERAÇÃO DA EQUIPE DE TI', 1466),
(12, 1, 'A TAREFA FOI COLOCADA EM 50% CONCLUÍDA, O QUE FALTA PARA FICAR 100%', 1476),
(13, 1, 'HÁ ALGUM IMPEDIMENTO DA PARTE DO MINICOM QUANTO A INSTALAÇÃO DE UM PAG EM LOCAL QUE NÃO SEJA DE PROPRIEDADE DO MUNICÍPIO', 1487),
(14, 1, 'QUAIS DADOS NECESSÁRIOS PARA A DEFINIÇÃO DOS SITES', 1491),
(15, 1, 'POR ONDE DEVE SER FEITO O ENVIO DO OFÍCIO', 1495),
(16, 1, 'no results', -1),
(17, 1, 'no results', -1),
(18, 1, 'no results', -1),
(19, 1, 'no results', -1),
(20, 1, 'no results', -1),
(21, 1, 'no results', -1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `undefined_defaults`
--

CREATE TABLE IF NOT EXISTS `undefined_defaults` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bot_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `pattern` text NOT NULL,
  `template` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `undefined_defaults`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `unknown_inputs`
--

CREATE TABLE IF NOT EXISTS `unknown_inputs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bot_id` int(11) NOT NULL,
  `input` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `unknown_inputs`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` text NOT NULL,
  `session_id` varchar(255) NOT NULL,
  `bot_id` int(11) NOT NULL,
  `chatlines` int(11) NOT NULL,
  `ip` varchar(100) NOT NULL,
  `referer` text NOT NULL,
  `browser` text NOT NULL,
  `date_logged_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_update` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `state` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=52 ;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `user_name`, `session_id`, `bot_id`, `chatlines`, `ip`, `referer`, `browser`, `date_logged_on`, `last_update`, `state`) VALUES
(1, 'Seeker', 'ultd3iqgdddclu3l5ps8dbemh5', 1, 0, '::1', 'http://localhost/master/gui/plain/?bot_id=1', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:29.0) Gecko/20100101 Firefox/29.0', '2014-06-20 12:59:54', '2014-06-20 12:59:54', ''),
(2, 'Seeker', '0oe18d9s7o395lim0sio99ksv6', 1, 0, '::1', 'http://localhost/master/gui/plain/', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:29.0) Gecko/20100101 Firefox/29.0', '2014-06-20 13:20:48', '2014-06-20 13:20:48', ''),
(3, 'Seeker', 'ad4t62qhgs2ioehsteomd3njp2', 1, 0, '::1', 'http://localhost/master/gui/plain/', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:29.0) Gecko/20100101 Firefox/29.0', '2014-07-04 10:17:10', '2014-07-04 10:17:10', ''),
(4, 'Seeker', '8eta1p5kecgbt2lg718u0m7555', 1, 0, '::1', 'http://localhost/master/gui/plain/', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36', '2014-07-09 14:39:14', '2014-07-09 14:39:14', ''),
(5, 'Seeker', 'jqgcn3fo8guon1rojpv0cg1v80', 1, 0, '::1', '', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36', '2014-07-09 14:39:38', '2014-07-09 14:39:38', ''),
(6, 'Seeker', 'thj5smosf6v2082oa8intr47m1', 1, 0, '::1', '', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36', '2014-07-09 14:40:17', '2014-07-09 14:40:17', ''),
(7, 'Seeker', 'stv8anmmn7r1dua6uebksm0r57', 1, 0, '::1', '', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36', '2014-07-09 14:40:56', '2014-07-09 14:40:56', ''),
(8, 'Seeker', 'o5i3uu83l8u9sgg822ft98a8c6', 1, 0, '::1', 'http://localhost/master/gui/jquery/', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36', '2014-07-09 14:46:52', '2014-07-09 14:46:52', ''),
(9, 'Seeker', '3vao5stg8jfp63imnno95pps50', 1, 0, '::1', 'http://localhost/master/gui/plain/', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36', '2014-07-09 15:11:18', '2014-07-09 15:11:18', ''),
(10, 'Seeker', 'f2c0r398pumsdgra3u8g1deh63', 1, 0, '::1', '', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36', '2014-07-09 15:12:45', '2014-07-09 15:12:45', ''),
(11, 'Seeker', '97okj3r77cdhls7pm68jdpbcc0', 1, 0, '::1', 'http://localhost/master/gui/jquery/', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36', '2014-08-03 13:15:28', '2014-08-03 13:15:28', ''),
(12, 'Seeker', '1jp7dkr0546vuu518i5jrpic22', 1, 0, '::1', 'http://localhost/master/gui/plain/', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36', '2014-08-05 16:33:00', '2014-08-05 16:33:00', ''),
(13, 'Seeker', '3it4ps7bjskjj6312022dk9fq3', 1, 0, '::1', 'http://localhost/master/gui/jquery/', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36', '2014-08-05 16:33:25', '2014-08-05 16:33:25', ''),
(14, 'Seeker', '0jnrqn4rgvboc9gb2eun6mbbv7', 1, 0, '::1', 'http://localhost/master/gui/plain/', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36', '2014-08-05 16:56:21', '2014-08-05 16:56:21', ''),
(15, 'Seeker', 's4q278v4n7gpg7m7fnjbkfl5s3', 1, 0, '::1', 'http://localhost/master/gui/plain/', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36', '2014-08-05 18:06:18', '2014-08-05 18:06:18', ''),
(16, 'Seeker', 'egkmobopek3ecjspub829ea1h6', 1, 0, '::1', 'http://localhost/master/gui/plain/', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36', '2014-08-09 10:42:28', '2014-08-09 10:42:28', ''),
(17, 'Seeker', 'q7s4j46r68anhaqb0t52glat31', 1, 0, '::1', 'http://localhost/master/gui/plain/', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', '2014-08-20 12:59:29', '2014-08-20 12:59:29', ''),
(18, 'Seeker', '6k0fpmq0rfjqlig4217qm1ds14', 1, 0, '::1', 'http://localhost/master/gui/js/index.php', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:31.0) Gecko/20100101 Firefox/31.0', '2014-08-26 22:55:48', '2014-08-26 22:55:48', ''),
(19, 'Seeker', 'hggk6p5rea2fthg8ualkurmah6', 1, 0, '::1', 'http://192.168.0.3/master/gui/js/index.php', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', '2014-08-26 22:56:12', '2014-08-26 22:56:12', ''),
(20, 'Seeker', 'mpu6mo7ptqd68q81fm1nd04gf1', 1, 0, '::1', 'http://localhost/master/gui/js/index.php', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:31.0) Gecko/20100101 Firefox/31.0', '2014-08-27 22:02:23', '2014-08-27 22:02:23', ''),
(21, 'Seeker', 'ioje21kgqpd6vqpvjpbv1gh4t2', 1, 0, '::1', 'http://localhost/master/gui/js/index.php', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', '2014-08-28 13:28:04', '2014-08-28 13:28:04', ''),
(22, 'Seeker', 'jt3n8hkg5esmha68hunnl9rkd3', 1, 0, '::1', 'http://localhost/master/gui/js/index.php', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:31.0) Gecko/20100101 Firefox/31.0', '2014-08-28 13:28:59', '2014-08-28 13:28:59', ''),
(23, 'Seeker', '262tv3ofm8g9j82sp7v42uqp22', 1, 0, '::1', 'http://localhost/master/gui/js/index.php', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', '2014-08-28 23:04:30', '2014-08-28 23:04:30', ''),
(24, 'Seeker', '48i9d0uacd3vctvj7usoq4g7v4', 1, 0, '::1', 'http://localhost/master/gui/js/index.php', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', '2014-08-29 14:41:37', '2014-08-29 14:41:37', ''),
(25, 'Seeker', '231vmd2o8tdt8m9dehknr28q36', 1, 0, '::1', 'http://localhost/master/gui/js/index.php', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', '2014-08-29 14:48:33', '2014-08-29 14:48:33', ''),
(26, 'Seeker', 'a8ko8hgm1v1rd338mtkks2fkr2', 1, 0, '::1', 'http://localhost/master/gui/jquery/index.php', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', '2014-08-29 14:50:45', '2014-08-29 14:50:45', ''),
(27, 'Seeker', 'el8kqnur8vs4qv7s49pj31s4u5', 1, 0, '::1', 'http://localhost/master/gui/jquery/index.php', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', '2014-08-29 14:51:23', '2014-08-29 14:51:23', ''),
(28, 'Seeker', '3h3oj84a42rqqefm1ibi4fu4s5', 1, 0, '::1', 'http://localhost/master/gui/plain/?bot_id=1', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', '2014-08-30 13:37:40', '2014-08-30 13:37:40', ''),
(29, 'Seeker', '8eh11kh2bqqhb8rr7r3cqaqgm6', 1, 0, '::1', 'http://localhost/master/gui/plain/?bot_id=1', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', '2014-08-30 16:22:11', '2014-08-30 16:22:11', ''),
(30, 'usuário', 'vapv30t4n50qum9ehbflm136i4', 1, 0, '177.194.175.242', 'http://localhost/master/gui/js/index.php', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', '2014-08-31 12:50:39', '2014-08-31 12:50:39', ''),
(31, 'usuário', '2eqt6bunas0fl8nnfan314i544', 1, 0, '177.194.175.242', 'http://linc.ufpa.br/sidmcbot/gui/js/index.php', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', '2014-08-31 13:15:49', '2014-08-31 13:15:49', ''),
(32, 'usuário', '7j1j6k1im810fmobsmkducapa2', 1, 0, '177.194.175.242', 'http://linc.ufpa.br/sidmcbot/gui/plain/?bot_id=1', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', '2014-08-31 13:31:11', '2014-08-31 13:31:11', ''),
(33, 'usuário', 'fa0ji86j18okoeltdcvjgbprq6', 1, 0, '177.194.175.242', 'http://linc.ufpa.br/sidmcbot/gui/plain/?bot_id=1', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', '2014-08-31 13:34:19', '2014-08-31 13:34:19', ''),
(34, 'usuário', 'gh04vh7hmj3705lm8efla15rv2', 1, 0, '177.194.175.242', 'http://linc.ufpa.br/sidmcbot/gui/plain/?bot_id=1', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', '2014-08-31 13:35:14', '2014-08-31 13:35:14', ''),
(35, 'usuário', '2ibbtedvrpob2t0sq4e3po1jo7', 1, 0, '191.247.226.139', 'http://linc.ufpa.br/sidmcbot/gui/plain/', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.103 Safari/537.36', '2014-09-04 15:00:25', '2014-09-04 15:00:25', ''),
(36, 'usuário', '6o8pjjbqtslciddtcl0cqhede6', 1, 0, '191.247.226.139', 'http://linc.ufpa.br/sidmcbot/gui/js/index.php', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.103 Safari/537.36', '2014-09-04 15:02:47', '2014-09-04 15:02:47', ''),
(37, 'usuário', '6rhk8snkpp8tdc4fdg1condj94', 1, 0, '191.247.226.139', 'http://linc.ufpa.br/sidmcbot/gui/plain/', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:31.0) Gecko/20100101 Firefox/31.0', '2014-09-04 16:46:22', '2014-09-04 16:46:22', ''),
(38, 'usuário', 's3c4286fadv049tgnqn6hhnl06', 1, 0, '191.247.226.154', 'http://linc.ufpa.br/sidmcbot/gui/js/index.php', 'Mozilla/5.0 (Linux; Android 4.4.4; XT1058 Build/KXA21.12-L1.26) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.117 Mobile Safari/537.36', '2014-09-05 11:06:45', '2014-09-05 11:06:45', ''),
(39, 'usuário', 'enkkk6k94s2vtab1ju72db0rg0', 1, 0, '191.247.226.154', 'http://linc.ufpa.br/sidmcbot/gui/plain/', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.103 Safari/537.36', '2014-09-05 11:43:35', '2014-09-05 11:43:35', ''),
(40, 'usuário', '2humoudkl7gudlm8pb0th17bf1', 1, 0, '179.171.155.23', 'http://www.linc.ufpa.br/sidmcbot/gui/js/', 'Mozilla/5.0 (Linux; Android 4.4.2; pt-br; SAMSUNG GT-I9505 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Version/1.5 Chrome/28.0.1500.94 Mobile Safari/537.36', '2014-09-06 09:56:45', '2014-09-06 09:56:45', ''),
(41, 'usuário', 'ukq41oi9ike0p5i44c4h9m7qq3', 1, 0, '179.171.155.23', 'http://www.linc.ufpa.br/sidmcbot/gui/js/', 'Mozilla/5.0 (Android; Mobile; rv:32.0) Gecko/32.0 Firefox/32.0', '2014-09-06 09:58:18', '2014-09-06 09:58:18', ''),
(42, 'usuário', 'po82pfbaq28ch0e4846g0k1bc2', 1, 0, '200.239.72.1', 'http://linc.ufpa.br/sidmcbot/gui/js/', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.103 Safari/537.36', '2014-09-06 10:47:34', '2014-09-06 10:47:34', ''),
(43, 'usuário', 'chj4tn63ue0c2iia5jf5o1h0r7', 1, 0, '200.239.72.1', 'http://linc.ufpa.br/sidmcbot/gui/plain/', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.103 Safari/537.36', '2014-09-06 13:23:11', '2014-09-06 13:23:11', ''),
(44, 'usuário', 'n1i62fkdhrcecqrqq8nbcmie97', 1, 0, '200.239.72.1', 'http://linc.ufpa.br/sidmcbot/gui/plain/', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.103 Safari/537.36', '2014-09-06 13:24:03', '2014-09-06 13:24:03', ''),
(45, 'usuário', 'aksjn7g1ah7e0astkhsmmh8m83', 1, 0, '200.239.72.1', 'http://linc.ufpa.br/sidmcbot/gui/plain/index.php', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.103 Safari/537.36', '2014-09-08 10:21:49', '2014-09-08 10:21:49', ''),
(46, 'usuário', '2s0oupf3vpmut4uarnfh5b9p32', 1, 0, '200.239.72.1', 'http://linc.ufpa.br/sidmcbot/gui/plain/', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.103 Safari/537.36', '2014-09-08 10:22:07', '2014-09-08 10:22:07', ''),
(47, 'usuário', 'rqthsvcv1a9mtdq9dargval0c3', 1, 0, '200.239.72.1', 'http://linc.ufpa.br/sidmcbot/gui/plain/', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.103 Safari/537.36', '2014-09-08 14:34:34', '2014-09-08 14:34:34', ''),
(48, 'usuário', 'j95kd5pp22l9ekmqtdmfkcr126', 1, 0, '200.239.72.1', 'http://linc.ufpa.br/sidmcbot/gui/js/', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.103 Safari/537.36', '2014-09-08 14:42:05', '2014-09-08 14:42:05', ''),
(49, 'usuário', 'tlnr0n3ufk0ssinf9c5dt7ha06', 1, 0, '200.239.72.1', 'http://linc.ufpa.br/sidmcbot/gui/plain/', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.103 Safari/537.36', '2014-09-08 16:01:45', '2014-09-08 16:01:45', ''),
(50, 'usuário', '8dptnseaifmo5cnk5v19qv8nk3', 1, 0, '200.239.72.1', 'http://linc.ufpa.br/sidmcbot/gui/plain/', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.103 Safari/537.36', '2014-09-08 16:01:57', '2014-09-08 16:01:57', ''),
(51, 'usuário', '7hs7ffletc0t5p8v7kma0djsb5', 1, 0, '200.239.72.1', 'http://linc.ufpa.br/sidmcbot/gui/plain/', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.103 Safari/537.36', '2014-09-08 16:04:15', '2014-09-08 16:04:15', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `wordcensor`
--

CREATE TABLE IF NOT EXISTS `wordcensor` (
  `censor_id` int(11) NOT NULL AUTO_INCREMENT,
  `word_to_censor` varchar(50) NOT NULL,
  `replace_with` varchar(50) NOT NULL DEFAULT '****',
  `bot_exclude` varchar(255) NOT NULL,
  PRIMARY KEY (`censor_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Extraindo dados da tabela `wordcensor`
--

INSERT INTO `wordcensor` (`censor_id`, `word_to_censor`, `replace_with`, `bot_exclude`) VALUES
(1, 'shit', 's***', ''),
(2, 'fuck', 'f***', '');

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `cidade`
--
ALTER TABLE `cidade`
  ADD CONSTRAINT `estadoFK` FOREIGN KEY (`estado_id`) REFERENCES `estado` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `replacements`
--
ALTER TABLE `replacements`
  ADD CONSTRAINT `localidadeFK` FOREIGN KEY (`cidade_id`) REFERENCES `cidade` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
